#!/usr/bin/env python3
"""
Tests STT - SuperWhisper V6
🚨 CONFIGURATION GPU: RTX 3090 (CUDA:1) OBLIGATOIRE

Tests pour le module STT
""" 